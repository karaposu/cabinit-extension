export const SETUP_REDIRECTION_PAGE = "https://www.hasantezcan.dev/";
// export const SETUP_REDIRECTION_PAGE = "https://www.freeads.co.uk/";
