export const felixSites = [
  {
    name: "zara.com",
    url: "https://www.zara.com",
    logo: "https://pluspng.com/img-png/zara-logo-png-zara-logo-png-and-vector-logo-img-4096x4096.png",
  },
  {
    name: "asos.com",
    url: "https://www.asos.com/",
    logo: "https://thestylefeeds.com/wp-content/uploads/2020/03/Asos-Logo-1280x419.png",
  },
  {
    name: "zalando.com",
    url: "https://www.zalando.co.uk/",
    logo: "https://alchetron.com/cdn/zalando-189a3a2d-0541-419b-a961-95cdbf9d0ec-resize-750.png",
  },
  {
    name: "HM.com",
    url: "https://www2.hm.com/en_gb/index.html",
    logo: "https://yellowscene.com/wp-content/uploads/2015/06/2000px-HM-Logo.svg_.gif",
  },
];
