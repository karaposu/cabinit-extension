// NOTE: You can change the content of the page here
export const ImageSelectorContent = {
  title: "Image Selector",
  description: "Please select an image from the list below.",
};
