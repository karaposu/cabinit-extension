export enum FelixTabs {
  Settings = "Settings",
  MyHeadDrops = "My Head Drops",
  DemoPage = "Demo Page",
  FelixSites = "Supported Sites",
}
