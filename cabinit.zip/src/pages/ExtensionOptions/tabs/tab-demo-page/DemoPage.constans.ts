export const demoImages = [
  {
    src: "https://cdn.dsmcdn.com/ty541/product/media/images/20220927/9/180217542/559095543/2/2_org_zoom.jpg",
    alt: "Image 1",
  },
  {
    src: "https://cdn.dsmcdn.com/ty822/product/media/images/20230412/17/323290668/909324057/1/1_org_zoom.jpg",
    alt: "Image 2",
  },
  {
    src: "https://cdn.dsmcdn.com/ty781/product/media/images/20230316/18/304908381/887593989/1/1_org_zoom.jpg",
    alt: "Image 3",
  },
  {
    src: "https://cdn.dsmcdn.com/ty968/product/media/images/20230717/12/394433305/979149374/1/1_org_zoom.jpg",
    alt: "Image 4",
  },
];
