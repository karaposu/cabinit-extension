export enum FelixPopupTabs {
  Intro = "Intro",
  MainMenu = "MainMenu",
  Navigation = "Navigation",
}
