// NOTE: You can change the content of the popup here
export const PopupContent = {
  welcomeTitle: "Welcome to Cabinit!",
  welcomeText:
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatum mollitia quae est sequi rerum nesciunt accusantium nulla tempore consequatur ipsum.",
  welcomeSummary: "Reiciendis iusto provident nemo vero quam laboriosam incidunt maiores qui! ✨",
  setupPageButton: "Setup Page",
  letsFelixButton: "Let's Cabinit!",
};
